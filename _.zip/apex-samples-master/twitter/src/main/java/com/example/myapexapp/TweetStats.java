package com.example.myapexapp;

public class TweetStats
{
  public long timestamp;
  public long total;
  public long withURL;
  public long withHashtag;
}
